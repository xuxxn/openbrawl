"""
Arena CMD Bot - Гибридная система
Telegram бот + CMD клиент
"""
import logging
import asyncio
import json
import random
import string
import websockets
import threading
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# ===== CONFIG =====
BOT_TOKEN = "8451980395:AAE2Bap_qBfHp6LTgIvQdkb4T57td-c-jQ0"  # Замените на ваш токен
WS_PORT = 8765  # Порт для WebSocket сервера

# ===== LOGGING =====
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ===== DATA STORAGE =====
class GameData:
    def __init__(self):
        self.pairing_codes = {}  # code -> {username, expires}
        self.players = {}  # user_id -> {username, token, status}
        self.queue = []  # [(user_id, username)]
        self.matches = {}  # match_id -> {player1, player2, game_state}
        self.websocket_clients = {}  # token -> websocket
        
    def generate_code(self, username):
        """Генерирует 6-значный код для пользователя"""
        # Удаляем старые коды этого пользователя
        codes_to_remove = [c for c, data in self.pairing_codes.items() if data['username'] == username]
        for c in codes_to_remove:
            del self.pairing_codes[c]
        
        code = ''.join(random.choices(string.digits, k=6))
        self.pairing_codes[code] = {
            'username': username,
            'user_id': None,
            'expires': datetime.now() + timedelta(minutes=5),
            'token': ''.join(random.choices(string.ascii_letters + string.digits, k=32))
        }
        return code
    
    def verify_code(self, code, username):
        """Проверяет код и возвращает токен"""
        if code not in self.pairing_codes:
            return None
        
        data = self.pairing_codes[code]
        if data['username'] != username:
            return None
        
        if datetime.now() > data['expires']:
            del self.pairing_codes[code]
            return None
        
        return data['token']

game_data = GameData()

# ===== WEBSOCKET SERVER =====
class CMDServer:
    def __init__(self):
        self.clients = {}
        self.matches = {}
        
    async def handle_client(self, websocket):
        """Обработка подключения клиента CMD"""
        client_token = None
        client_addr = websocket.remote_address if hasattr(websocket, 'remote_address') else ('unknown', 0)
        logger.info(f"[WS] New connection from {client_addr}")
        
        try:
            async for message in websocket:
                logger.info(f"[WS] Received message: {message}")
                try:
                    data = json.loads(message)
                except json.JSONDecodeError as e:
                    logger.error(f"[WS] Invalid JSON: {e}")
                    continue
                msg_type = data.get('type')
                logger.info(f"[WS] Message type: {msg_type}")
                
                if msg_type == 'auth':
                    # Авторизация по токену
                    token = data.get('token')
                    username = data.get('username')
                    logger.info(f"[AUTH] Attempt from {username} with token {token[:20]}...")
                    logger.info(f"[AUTH] Available codes: {list(game_data.pairing_codes.keys())}")
                    
                    token_valid = False
                    matched_code = None
                    
                    # Проверяем по коду в pairing_codes
                    for code, pdata in game_data.pairing_codes.items():
                        logger.info(f"[AUTH] Checking code {code} for user {pdata['username']}, expires {pdata['expires']}")
                        if pdata['username'] == username:
                            if datetime.now() <= pdata['expires']:
                                if token == f"{username}_{code}" or token == pdata['token']:
                                    token_valid = True
                                    matched_code = code
                                    logger.info(f"[AUTH] Token valid for code {code}")
                                    break
                            else:
                                logger.info(f"[AUTH] Code {code} expired")
                    
                    if token_valid:
                        client_token = token
                        self.clients[token] = {
                            'websocket': websocket,
                            'username': username,
                            'status': 'online'
                        }
                        
                        logger.info(f"[AUTH] Client {username} authorized successfully")
                        
                        try:
                            await websocket.send(json.dumps({
                                'type': 'auth_success',
                                'message': 'Authorized successfully'
                            }))
                            logger.info(f"[AUTH] Auth success sent to {username}")
                        except Exception as e:
                            logger.error(f"[AUTH] Failed to send auth success: {e}")
                            return
                        
                        # Добавляем в очередь матчмейкинга
                        await self.add_to_matchmaking(token, username)
                    else:
                        logger.warning(f"[AUTH] Invalid token for {username}")
                        try:
                            await websocket.send(json.dumps({
                                'type': 'error',
                                'message': 'Invalid token'
                            }))
                        except Exception as e:
                            logger.error(f"[AUTH] Failed to send error: {e}")
                
                elif msg_type == 'move':
                    # Обработка движения
                    if client_token:
                        await self.handle_move(client_token, data.get('direction'))
                
                elif msg_type == 'disconnect':
                    break
                    
        except websockets.exceptions.ConnectionClosed as e:
            logger.info(f"Connection closed: {e}")
        except Exception as e:
            logger.error(f"Error in handle_client: {e}")
            import traceback
            logger.error(traceback.format_exc())
        finally:
            if client_token and client_token in self.clients:
                await self.handle_disconnect(client_token)
    
    async def add_to_matchmaking(self, token, username):
        """Добавление в очередь матчмейкинга"""
        # Ищем свободного игрока
        for other_token, client in self.clients.items():
            if other_token != token and client.get('status') == 'waiting':
                # Создаем матч!
                match_id = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
                
                self.matches[match_id] = {
                    'player1': token,
                    'player2': other_token,
                    'p1_pos': [0, 0],
                    'p2_pos': [9, 9],
                    'turn': 0
                }
                
                self.clients[token]['status'] = 'playing'
                self.clients[token]['match_id'] = match_id
                client['status'] = 'playing'
                client['match_id'] = match_id
                
                # Уведомляем обоих
                await self.notify_match_found(match_id)
                return
        
        # Никого нет - ждем
        self.clients[token]['status'] = 'waiting'
        await self.clients[token]['websocket'].send(json.dumps({
            'type': 'status',
            'message': 'Waiting for opponent...'
        }))
    
    async def notify_match_found(self, match_id):
        """Уведомление о найденном матче"""
        match = self.matches[match_id]
        p1_token = match['player1']
        p2_token = match['player2']
        
        logger.info(f"[MATCH] Notifying players about match {match_id}")
        logger.info(f"[MATCH] Player 1: {p1_token[:20]}..., Player 2: {p2_token[:20]}...")
        
        p1_client = self.clients.get(p1_token)
        p2_client = self.clients.get(p2_token)
        
        if not p1_client or not p2_client:
            logger.error("[MATCH] One of the clients not found!")
            return
        
        p1_ws = p1_client['websocket']
        p2_ws = p2_client['websocket']
        
        # Отправляем игроку 1
        try:
            state1 = {
                'type': 'match_found',
                'match_id': match_id,
                'field_size': 10,
                'player1_pos': match['p1_pos'],
                'player2_pos': match['p2_pos'],
                'your_player': 1
            }
            await p1_ws.send(json.dumps(state1))
            logger.info(f"[MATCH] Sent to player 1")
        except Exception as e:
            logger.error(f"[MATCH] Failed to notify player 1: {e}")
        
        # Отправляем игроку 2
        try:
            state2 = {
                'type': 'match_found',
                'match_id': match_id,
                'field_size': 10,
                'player1_pos': match['p1_pos'],
                'player2_pos': match['p2_pos'],
                'your_player': 2
            }
            await p2_ws.send(json.dumps(state2))
            logger.info(f"[MATCH] Sent to player 2")
        except Exception as e:
            logger.error(f"[MATCH] Failed to notify player 2: {e}")
    
    async def handle_move(self, token, direction):
        """Обработка движения игрока"""
        logger.info(f"[MOVE] Received move from {token[:20]}... direction={direction}")
        
        client = self.clients.get(token)
        if not client:
            logger.warning(f"[MOVE] Client not found for token {token[:20]}...")
            return
        
        if client['status'] != 'playing':
            logger.warning(f"[MOVE] Client status is {client['status']}, not playing")
            return
        
        match_id = client.get('match_id')
        if not match_id:
            logger.warning("[MOVE] Client has no match_id")
            return
            
        if match_id not in self.matches:
            logger.warning(f"[MOVE] Match {match_id[:20]}... not found")
            return
        
        match = self.matches[match_id]
        is_p1 = match['player1'] == token
        pos_key = 'p1_pos' if is_p1 else 'p2_pos'
        
        x, y = match[pos_key]
        old_pos = [x, y]
        
        if direction == 'w' and y > 0:
            y -= 1
        elif direction == 's' and y < 9:
            y += 1
        elif direction == 'a' and x > 0:
            x -= 1
        elif direction == 'd' and x < 9:
            x += 1
        
        new_pos = [x, y]
        match[pos_key] = new_pos
        
        logger.info(f"[MOVE] Player moved from {old_pos} to {new_pos}")
        
        # Отправляем обновление обоим
        update = {
            'type': 'game_update',
            'player1_pos': match['p1_pos'],
            'player2_pos': match['p2_pos']
        }
        
        try:
            p1_ws = self.clients[match['player1']]['websocket']
            await p1_ws.send(json.dumps(update))
            logger.info("[MOVE] Sent update to player 1")
        except Exception as e:
            logger.error(f"[MOVE] Failed to send to player 1: {e}")
        
        try:
            p2_ws = self.clients[match['player2']]['websocket']
            await p2_ws.send(json.dumps(update))
            logger.info("[MOVE] Sent update to player 2")
        except Exception as e:
            logger.error(f"[MOVE] Failed to send to player 2: {e}")
    
    async def handle_disconnect(self, token):
        """Обработка отключения"""
        client = self.clients.get(token)
        if client and client.get('status') == 'playing':
            match_id = client.get('match_id')
            if match_id and match_id in self.matches:
                match = self.matches[match_id]
                opponent_token = match['player2'] if match['player1'] == token else match['player1']
                
                if opponent_token in self.clients:
                    await self.clients[opponent_token]['websocket'].send(json.dumps({
                        'type': 'opponent_disconnected'
                    }))
                
                del self.matches[match_id]
        
        if token in self.clients:
            del self.clients[token]
    
    async def start(self):
        """Запуск WebSocket сервера"""
        async with websockets.serve(self.handle_client, "localhost", WS_PORT):
            logger.info(f"WebSocket server started on ws://localhost:{WS_PORT}")
            await asyncio.Future()  # Бесконечное ожидание

cmd_server = CMDServer()

# ===== TELEGRAM BOT =====
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начало работы с ботом"""
    username = update.effective_user.username
    user_id = update.effective_user.id
    
    if not username:
        await update.message.reply_text(
            "⚠️ У вас нет username в Telegram!\n"
            "Пожалуйста, установите username в настройках."
        )
        return
    
    # Генерируем код
    code = game_data.generate_code(username)
    
    await update.message.reply_text(
        f"👋 Привет, @{username}!\n\n"
        f"🎮 Добро пожаловать в Arena CMD!\n\n"
        f"Ваш код: <b>{code}</b>\n"
        f"⏰ Действует 5 минут\n\n"
        f"1. Установите клиент: <code>pip install arena-cmd</code>\n"
        f"2. Запустите: <code>arena</code>\n"
        f"3. Введите код: <b>{code}</b>\n\n"
        f"Команды:\n"
        f"/play - Найти игру\n"
        f"/status - Проверить статус\n"
        f"/code - Новый код",
        parse_mode='HTML'
    )

async def code_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Новый код"""
    username = update.effective_user.username
    if not username:
        await update.message.reply_text("⚠️ Установите username!")
        return
    
    code = game_data.generate_code(username)
    await update.message.reply_text(
        f"🔑 Новый код: <b>{code}</b>\n"
        f"⏰ Действует 5 минут",
        parse_mode='HTML'
    )

async def play_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Поиск игры"""
    username = update.effective_user.username
    if not username:
        await update.message.reply_text("⚠️ Установите username!")
        return
    
    await update.message.reply_text(
        "🎮 Запустите клиент и введите код!\n\n"
        "Как только подключитесь, начнется матчмейкинг."
    )

async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Проверка статуса"""
    username = update.effective_user.username
    
    # Проверяем, есть ли код
    for code, data in game_data.pairing_codes.items():
        if data['username'] == username:
            await update.message.reply_text(
                f"✅ Код активен: <b>{code}</b>\n"
                f"Запустите клиент для игры!",
                parse_mode='HTML'
            )
            return
    
    await update.message.reply_text(
        "❌ Нет активного кода\n"
        "Используйте /start или /code"
    )

# ===== MAIN =====
def run_websocket_server():
    """Запуск WebSocket сервера в отдельном потоке"""
    asyncio.run(cmd_server.start())

def main():
    """Запуск бота"""
    
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ ОШИБКА: Укажите BOT_TOKEN в bot.py")
        return
    
    # Запускаем WebSocket сервер в фоне
    ws_thread = threading.Thread(target=run_websocket_server, daemon=True)
    ws_thread.start()
    
    # Создаем бота
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Добавляем обработчики
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("code", code_cmd))
    application.add_handler(CommandHandler("play", play_cmd))
    application.add_handler(CommandHandler("status", status_cmd))
    
    print("🤖 Бот запущен!")
    print(f"📡 WebSocket сервер на порту {WS_PORT}")
    print("⏳ Ожидание подключений...")
    
    # Запускаем бота
    application.run_polling()

if __name__ == "__main__":
    main()
