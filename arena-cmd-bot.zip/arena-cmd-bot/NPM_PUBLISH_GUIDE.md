# 📦 Публикация OpenBrawl на npm

## Что получится:

```bash
# Установка
npm install -g openbrawl

# Запуск
openbrawl

# Или без установки
npx openbrawl
```

## Шаги публикации:

### 1. Подготовка

**У вас должно быть:**
- GitHub репозиторий с релизами
- Собранные бинарники (openbrawl.exe, openbrawl-linux, openbrawl-macos)
- Аккаунт на npmjs.com

### 2. Сборка бинарников

```bash
cd C:\GameProject\arena-cmd-bot

# Windows
build_exe.bat
copy dist\arena.exe ..\releases\openbrawl-windows.exe

# Linux (через WSL или CI/CD)
./build_exe.sh
cp dist/arena ../releases/openbrawl-linux

# macOS (на Mac)
./build_exe.sh
cp dist/arena ../releases/openbrawl-macos
```

### 3. Создание GitHub Release

1. Зайдите на https://github.com/yourusername/openbrawl/releases
2. Нажмите "Draft a new release"
3. Создайте тег: `v1.0.0`
4. Загрузите файлы:
   - `openbrawl-windows.exe`
   - `openbrawl-linux`
   - `openbrawl-macos`
5. Опубликуйте

### 4. Настройка npm пакета

Отредактируйте `npm-package/package.json`:
```json
{
  "name": "openbrawl",
  "repository": {
    "type": "git",
    "url": "git+https://github.com/YOUR_USERNAME/openbrawl.git"
  }
}
```

Отредактируйте `npm-package/install.js`:
```javascript
const REPO = 'YOUR_USERNAME/openbrawl'; // Ваш репозиторий
```

### 5. Вход в npm

```bash
npm login
# Введите username, password, email
```

### 6. Публикация

```bash
# Windows
npm-package\publish.bat

# Linux/Mac
bash npm-package/publish.sh
```

Или вручную:
```bash
cd npm-package
npm version 1.0.0  # или patch/minor/major
npm publish --access public
```

### 7. Проверка

```bash
# Проверка установки
npm install -g openbrawl

# Запуск
openbrawl

# Или без установки
npx openbrawl
```

## 🔧 Как это работает:

1. Пользователь запускает `npm install -g openbrawl`
2. npm скачивает пакет (только JS файлы, ~5KB)
3. Автоматически выполняется `postinstall` скрипт
4. `install.js` скачивает нужный бинарник с GitHub Releases
5. `bin/arena.js` запускает скачанный бинарник

## 📁 Структура npm пакета:

```
npm-package/
├── package.json      # Метаданные пакета
├── install.js        # Скачивание бинарника
├── bin/
│   └── arena.js      # CLI точка входа
└── README.md         # Документация
```

## ⚠️ Важно:

- **Бинарники не включены в npm пакет** - они скачиваются при установке
- Это позволяет пакету быть маленьким (~5KB vs 10MB+)
- Поддерживаются Windows, Linux, macOS
- Нужен Node.js 14+

## 🚀 Примеры использования:

**Для Windows пользователей:**
```cmd
npm install -g openbrawl
openbrawl

# Для Linux/Mac:
```bash
sudo npm install -g openbrawl
openbrawl
```

**Временный запуск (без установки):**
```bash
npx openbrawl
```

## 📝 package.json ключевые поля:

```json
{
  "name": "openbrawl",           // Имя пакета
  "version": "1.0.0",            // Версия
  "bin": {                        // CLI команды
    "arena": "./bin/arena.js"
  },
  "scripts": {
    "postinstall": "node install.js"  // Скачивание бинарника
  }
}
```

## 🎯 Преимущества npm подхода:

✅ Одинаковая команда для всех ОС  
✅ NPX позволяет запускать без установки  
✅ Автоматическое обновление через npm update  
✅ Знакомый интерфейс для JS разработчиков  
✅ Маленький начальный размер (скачивается только нужный бинарник)  

Готовы опубликовать? Соберите бинарники и запустите `npm-package\publish.bat`!
