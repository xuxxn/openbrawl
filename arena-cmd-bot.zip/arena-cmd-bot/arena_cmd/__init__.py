"""
Arena CMD - Telegram Multiplayer Game Client

Установка:
    pip install arena-cmd

Использование:
    arena
    
Или:
    python -m arena_cmd
"""

__version__ = "1.0.0"
__author__ = "Your Name"

from .client import main, GameClient

__all__ = ['main', 'GameClient']
