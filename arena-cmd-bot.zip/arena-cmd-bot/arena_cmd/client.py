"""
Arena CMD Client
Клиент для игры в терминале
"""
import asyncio
import json
import os
import sys
import threading
import time
import websockets
from colorama import init, Fore, Back, Style

init(autoreset=True)

# Конфигурация - по умолчанию localhost для тестирования
# В production замените на ваш Cloudflare URL
WS_URL = os.environ.get("ARENA_SERVER", "ws://localhost:8765")
CONFIG_FILE = os.path.expanduser("~/.arena_cmd_config.json")

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_config(config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def draw_field(p1_pos, p2_pos, my_player):
    """Отрисовка игрового поля"""
    clear_screen()
    
    print(Fore.CYAN + "╔" + "════════════════════╗")
    
    for y in range(10):
        row = "║"
        for x in range(10):
            if [x, y] == p1_pos:
                if my_player == 1:
                    row += Fore.GREEN + "🔵" + Fore.CYAN
                else:
                    row += Fore.RED + "🔴" + Fore.CYAN
            elif [x, y] == p2_pos:
                if my_player == 2:
                    row += Fore.GREEN + "🔵" + Fore.CYAN
                else:
                    row += Fore.RED + "🔴" + Fore.CYAN
            else:
                row += "  "
        row += "║"
        print(Fore.CYAN + row)
    
    print(Fore.CYAN + "╚" + "════════════════════╝")
    print(Fore.YELLOW + "\nУправление: W/A/S/D + Enter | Q + Enter - выход")
    
    if my_player == 1:
        print(Fore.GREEN + f"Вы: 🔵 на {p1_pos}")
        print(Fore.RED + f"Враг: 🔴 на {p2_pos}")
    else:
        print(Fore.GREEN + f"Вы: 🔵 на {p2_pos}")
        print(Fore.RED + f"Враг: 🔴 на {p1_pos}")

class GameClient:
    def __init__(self):
        self.websocket = None
        self.running = False
        self.my_player = 1
        self.p1_pos = [0, 0]
        self.p2_pos = [9, 9]
        self.current_input = None
        self.input_lock = threading.Lock()
        self.use_keyboard = False
        self.input_queue = []
    
    def read_input_manual(self):
        """Ручной ввод через input()"""
        while self.running:
            try:
                char = input().strip().lower()
                if char in ['w', 'a', 's', 'd']:
                    with self.input_lock:
                        self.current_input = char
                    print(Fore.CYAN + f"[INPUT] Command: {char}")
                elif char == 'q':
                    print(Fore.YELLOW + "[INPUT] Quit command")
                    self.running = False
                    break
            except:
                pass
            time.sleep(0.1)
    
    async def connect(self, token, username):
        self.running = True
        
        print(Fore.GREEN + "✅ Режим ввода: введите w/a/s/d и нажмите Enter")
        print(Fore.YELLOW + "ℹ️ q + Enter для выхода")
        
        # Запускаем поток для ручного ввода
        input_thread = threading.Thread(target=self.read_input_manual, daemon=True)
        input_thread.start()
        
        try:
            print(Fore.YELLOW + f"[DEBUG] Connecting to {WS_URL}...")
            async with websockets.connect(WS_URL) as ws:
                self.websocket = ws
                print(Fore.GREEN + "[DEBUG] Connected!")
                
                # Авторизация
                auth_msg = json.dumps({
                    'type': 'auth',
                    'token': token,
                    'username': username
                })
                print(Fore.YELLOW + f"[DEBUG] Sending auth...")
                await ws.send(auth_msg)
                
                await asyncio.gather(
                    self.receive_messages(),
                    self.send_inputs()
                )
        except Exception as e:
            print(Fore.RED + f"\n❌ Ошибка: {e}")
        finally:
            self.running = False
    
    async def receive_messages(self):
        try:
            while self.running:
                try:
                    msg = await asyncio.wait_for(self.websocket.recv(), timeout=0.5)
                except asyncio.TimeoutError:
                    continue
                    
                data = json.loads(msg)
                msg_type = data.get('type')
                
                if msg_type == 'auth_success':
                    print(Fore.GREEN + f"\n✅ {data.get('message')}")
                
                elif msg_type == 'status':
                    print(Fore.YELLOW + f"\n⏳ {data.get('message')}")
                
                elif msg_type == 'match_found':
                    print(Fore.GREEN + "\n🎮 Матч найден!")
                    self.my_player = data.get('your_player', 1)
                    self.p1_pos = data.get('player1_pos', [0, 0])
                    self.p2_pos = data.get('player2_pos', [9, 9])
                    draw_field(self.p1_pos, self.p2_pos, self.my_player)
                
                elif msg_type == 'game_update':
                    self.p1_pos = data.get('player1_pos', self.p1_pos)
                    self.p2_pos = data.get('player2_pos', self.p2_pos)
                    draw_field(self.p1_pos, self.p2_pos, self.my_player)
                
                elif msg_type == 'opponent_disconnected':
                    print(Fore.RED + "\n❌ Соперник отключился")
                    self.running = False
        except asyncio.TimeoutError:
            pass
    
    async def send_inputs(self):
        """Отправка ввода на сервер"""
        while self.running:
            key = None
            
            with self.input_lock:
                if self.current_input:
                    key = self.current_input
                    self.current_input = None
            
            if key and self.websocket:
                try:
                    msg = json.dumps({
                        'type': 'move',
                        'direction': key
                    })
                    print(Fore.CYAN + f"[SEND] Sending move: {key}")
                    await self.websocket.send(msg)
                except Exception as e:
                    print(Fore.RED + f"[SEND] Error: {e}")
            
            await asyncio.sleep(0.1)

def main():
    print(Fore.CYAN + "🎮 OpenBrawl Client\n")
    
    config = load_config()
    
    if 'token' in config:
        print(Fore.GREEN + "✅ Найдена сохраненная сессия")
        use = input("Использовать? (y/n): ").lower().strip()
        
        if use == 'y':
            token = config['token']
            username = config.get('username', 'unknown')
        else:
            token = None
    else:
        token = None
    
    if not token:
        print(Fore.YELLOW + "\n📱 Авторизация\n")
        print("1. Напишите боту /start")
        print("2. Получите 6-значный код")
        print("3. Введите данные:\n")
        
        username = input("Username: ").strip().lstrip('@')
        code = input("Код: ").strip()
        
        token = f"{username}_{code}"
        
        config['token'] = token
        config['username'] = username
        save_config(config)
        print(Fore.GREEN + "✅ Сохранено")
    
    print(Fore.YELLOW + "\n🌐 Подключение...")
    client = GameClient()
    
    try:
        asyncio.run(client.connect(token, username))
    except KeyboardInterrupt:
        print(Fore.YELLOW + "\n\n👋 До свидания!")

if __name__ == "__main__":
    main()
