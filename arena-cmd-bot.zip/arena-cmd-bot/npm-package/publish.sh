#!/bin/bash

# Скрипт для публикации на npm

echo "🚀 Публикация Arena CMD на npm"
echo

# Проверяем, вошли ли мы в npm
npm whoami > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "❌ Вы не вошли в npm"
    echo "   Выполните: npm login"
    exit 1
fi

echo "✅ Проверка авторизации"
echo

# Переходим в директорию пакета
cd npm-package

# Обновляем версию
echo "Текущая версия:"
cat package.json | grep version

echo
echo "1) Обновить патч (1.0.0 -> 1.0.1)"
echo "2) Обновить минор (1.0.0 -> 1.1.0)"
echo "3) Обновить мажор (1.0.0 -> 2.0.0)"
echo "4) Ввести версию вручную"
read -p "Выберите действие (1-4): " choice

case $choice in
  1) npm version patch ;;
  2) npm version minor ;;
  3) npm version major ;;
  4) 
    read -p "Введите версию (например 1.0.1): " version
    npm version $version
    ;;
  *) echo "Неверный выбор"; exit 1 ;;
esac

# Публикуем
echo
echo "📤 Публикация на npm..."
npm publish --access public

if [ $? -eq 0 ]; then
    echo
    echo "✅ Опубликовано!"
    echo "   npm install -g arena-cmd"
else
    echo
    echo "❌ Ошибка публикации"
fi
