#!/usr/bin/env node

/**
 * Install script for OpenBrawl
 * Скачивает бинарник при установке npm пакета
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');

const VERSION = '1.0.0';
const REPO = 'yourusername/openbrawl'; // Замените на ваш репозиторий

// URL для скачивания
const DOWNLOAD_URLS = {
  win32: `https://github.com/${REPO}/releases/download/v${VERSION}/openbrawl-windows.exe`,
  linux: `https://github.com/${REPO}/releases/download/v${VERSION}/openbrawl-linux`,
  darwin: `https://github.com/${REPO}/releases/download/v${VERSION}/openbrawl-macos`
};

function downloadFile(url, dest) {
  return new Promise((resolve, reject) => {
    console.log(`📥 Скачивание OpenBrawl...`);
    
    const file = fs.createWriteStream(dest);
    https.get(url, { followRedirect: true }, (response) => {
      if (response.statusCode === 301 || response.statusCode === 302) {
        downloadFile(response.headers.location, dest)
          .then(resolve)
          .catch(reject);
        return;
      }
      
      if (response.statusCode !== 200) {
        reject(new Error(`HTTP ${response.statusCode}`));
        return;
      }

      const totalSize = parseInt(response.headers['content-length'], 10);
      let downloaded = 0;

      response.on('data', (chunk) => {
        downloaded += chunk.length;
        if (totalSize) {
          const percent = Math.round((downloaded / totalSize) * 100);
          process.stdout.write(`\r   Прогресс: ${percent}%`);
        }
      });

      response.pipe(file);

      file.on('finish', () => {
        file.close();
        console.log('\n✅ Скачано!');
        resolve();
      });
    }).on('error', (err) => {
      fs.unlink(dest, () => {});
      reject(err);
    });
  });
}

async function install() {
  console.log('🎮 Установка OpenBrawl...\n');

  const platform = os.platform();
  const binDir = path.join(__dirname, 'bin');
  
  // Создаем директорию bin
  if (!fs.existsSync(binDir)) {
    fs.mkdirSync(binDir, { recursive: true });
  }

  const exeName = platform === 'win32' ? 'openbrawl.exe' : 'openbrawl';
  const exePath = path.join(binDir, exeName);
  const downloadUrl = DOWNLOAD_URLS[platform];

  if (!downloadUrl) {
    console.error(`❌ Платформа ${platform} не поддерживается`);
    process.exit(1);
  }

  try {
    // Проверяем, не установлен ли уже
    if (fs.existsSync(exePath)) {
      console.log('✅ OpenBrawl уже установлен');
      return;
    }

    // Скачиваем
    await downloadFile(downloadUrl, exePath);

    // Делаем исполняемым (Unix)
    if (platform !== 'win32') {
      fs.chmodSync(exePath, 0o755);
    }

    console.log(`\n🎉 Установка завершена!`);
    console.log(`   Запуск: openbrawl`);
    
  } catch (error) {
    console.error(`\n❌ Ошибка установки: ${error.message}`);
    console.error('\nВозможные причины:');
    console.error('   - Нет подключения к интернету');
    console.error('   - Релиз не найден на GitHub');
    console.error('   - Неправильная версия');
    process.exit(1);
  }
}

// Запускаем установку
install();
