# OpenBrawl

🎮 **OpenBrawl** - Telegram multiplayer game in terminal

## Установка

```bash
npm install -g openbrawl
```

## Использование

```bash
openbrawl
```

## Без установки (NPX)

```bash
npx openbrawl
```

## Как играть

1. Установите: `npm install -g openbrawl`
2. Запустите: `openbrawl`
3. Напишите боту в Telegram: `@YourBotName`
4. Отправьте `/start` для получения кода
5. Введите код в терминале
6. Играйте!

## Управление

- **W/A/S/D** + Enter - движение
- **Q** + Enter - выход

## Удаление

```bash
npm uninstall -g openbrawl
```

## Лицензия

MIT
