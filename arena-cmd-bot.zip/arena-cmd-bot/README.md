<<<<<<< HEAD
# OpenBrawl

🎮 **OpenBrawl** - Telegram бот для многопользовательских игр в терминале!

## ⚡ Быстрый старт

### 1. Установка (выберите один способ)

**Способ A - NPM (рекомендуется):**
```bash
npm install -g openbrawl
```

**Способ B - Pip (если есть Python):**
```bash
pip install openbrawl
```

**Способ C - EXE (не нужен Python):**
Скачайте `openbrawl.exe` из [релизов](https://github.com/yourusername/openbrawl/releases)

**Способ D - Без установки:**
```bash
npx openbrawl
```

### 2. Запуск
```bash
openbrawl
```

### 3. Игра
1. Напишите боту в Telegram: `@YourBot`
2. Отправьте `/start` для получения кода
3. Введите код в терминале
4. Играйте! Управление: W/A/S/D + Enter

## 🎯 Команды

- **W/A/S/D** + Enter - движение
- **Q** + Enter - выход

## 🔧 Требования

- Windows 10/11 или Linux/macOS
- Для npm установки: Node.js 14+
- Для pip установки: Python 3.8+

## 📦 Установка для разработки

```bash
git clone https://github.com/yourusername/openbrawl.git
cd openbrawl
pip install -e .
```

## 🌐 Подключение к серверу

По умолчанию клиент подключается к `ws://localhost:8765`.

Для подключения к публичному серверу:
```bash
set OPENBRAWL_SERVER=wss://your-server.trycloudflare.com
openbrawl
```

## 📝 Лицензия

MIT License
=======
# openbrawl
>>>>>>> 328d4f20403920a97c6b27d66b7a91a947dc5d83
