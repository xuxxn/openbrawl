"""
Installer for Arena CMD
Скачивает и устанавливает arena.exe
"""
import urllib.request
import os
import sys
import zipfile
from pathlib import Path

INSTALL_DIR = Path.home() / "arena-cmd"
BIN_DIR = INSTALL_DIR / "bin"
EXE_URL = "https://github.com/yourusername/arena-cmd/releases/latest/download/arena-windows.zip"

def download_file(url, destination):
    """Скачивание файла с прогрессом"""
    print(f"📥 Скачивание {url}...")
    
    def report_progress(block_num, block_size, total_size):
        downloaded = block_num * block_size
        percent = min(downloaded * 100 / total_size, 100)
        sys.stdout.write(f"\r   Прогресс: {percent:.1f}%")
        sys.stdout.flush()
    
    urllib.request.urlretrieve(url, destination, reporthook=report_progress)
    print("\n✅ Скачано!")

def install():
    """Установка Arena CMD"""
    print("🎮 Установка Arena CMD\n")
    
    # Создаем директории
    print("📁 Создание директорий...")
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    
    # Скачиваем
    zip_path = INSTALL_DIR / "arena.zip"
    try:
        download_file(EXE_URL, zip_path)
    except Exception as e:
        print(f"❌ Ошибка скачивания: {e}")
        return False
    
    # Распаковываем
    print("📦 Распаковка...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(BIN_DIR)
    
    # Удаляем архив
    zip_path.unlink()
    
    # Добавляем в PATH
    print("🔧 Настройка PATH...")
    exe_path = BIN_DIR / "arena.exe"
    
    if exe_path.exists():
        print(f"✅ Установлено в: {exe_path}")
        print(f"\n⚠️ Добавьте в PATH вручную:")
        print(f"   {BIN_DIR}")
        print(f"\n   Или запускайте: {exe_path}")
        return True
    else:
        print("❌ Ошибка: arena.exe не найден")
        return False

def main():
    try:
        if install():
            print("\n🎉 Установка завершена!")
            print("\nЗапуск:")
            print("   arena")
            print("\nУдаление:")
            print(f"   Удалите папку: {INSTALL_DIR}")
        else:
            print("\n❌ Установка не удалась")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n⛔ Установка отменена")
        sys.exit(1)

if __name__ == "__main__":
    main()
