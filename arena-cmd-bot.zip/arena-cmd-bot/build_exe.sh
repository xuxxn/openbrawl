#!/bin/bash

echo "🔨 Сборка Arena CMD..."
echo

# Проверяем наличие pyinstaller
if ! python -c "import PyInstaller" 2>/dev/null; then
    echo "📦 Установка PyInstaller..."
    pip install pyinstaller
fi

echo "🧹 Очистка старых сборок..."
rm -rf dist build
rm -f arena.spec

echo "📦 Сборка EXE..."
pyinstaller --onefile --name arena --console arena_cmd/client.py

echo "✅ Готово!"
echo
echo "📁 EXE файл: dist/arena"
echo
echo "Для теста:"
echo "  ./dist/arena"
