# 🚀 Публикация через GitHub Actions

## Шаг 1: Создать репозиторий на GitHub

1. Зайдите на https://github.com/new
2. Название: `openbrawl`
3. Описание: `Telegram multiplayer game in terminal`
4. Публичный (Public)
5. **НЕ добавляйте** README, .gitignore, license (мы добавим свои)
6. Нажмите **Create repository**

## Шаг 2: Подготовить код

Выполните в терминале:

```bash
cd C:\GameProject\arena-cmd-bot

# Инициализируем git (если еще не сделано)
git init

# Добавляем файлы
git add .

# Коммит
git commit -m "Initial commit: OpenBrawl game"

# Привязываем к GitHub (замените YOUR_USERNAME на ваш ник)
git remote add origin https://github.com/YOUR_USERNAME/openbrawl.git

# Отправляем
git branch -M main
git push -u origin main
```

## Шаг 3: Настроить секреты (для публикации на npm)

1. Откройте репозиторий на GitHub
2. Перейдите в **Settings** → **Secrets and variables** → **Actions**
3. Нажмите **New repository secret**
4. Имя: `NPM_TOKEN`
5. Значение: ваш токен с npmjs.com (создайте на https://www.npmjs.com/settings/tokens)
6. **Add secret**

## Шаг 4: GitHub Actions workflow

Создайте файл `.github/workflows/publish.yml`:

```yaml
name: Publish to npm

on:
  release:
    types: [created]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          registry-url: 'https://registry.npmjs.org'
      
      - name: Install dependencies
        run: cd npm-package && npm ci
      
      - name: Publish to npm
        run: cd npm-package && npm publish --access public
        env:
          NODE_AUTH_TOKEN: ${{ secrets.NPM_TOKEN }}
```

## Шаг 5: Собрать EXE и создать релиз

```bash
# Собираем EXE
cd C:\GameProject\arena-cmd-bot
build_exe.bat

# Переименовываем
copy dist\arena.exe openbrawl-windows.exe

# Создаем тег
git tag -a v1.0.0 -m "Version 1.0.0"
git push origin v1.0.0
```

## Шаг 6: Создать релиз на GitHub

1. На GitHub зайдите в **Releases** → **Draft a new release**
2. Выберите тег: `v1.0.0`
3. Заголовок: `v1.0.0 - First release`
4. Описание:
```markdown
## OpenBrawl v1.0.0

🎮 Telegram multiplayer game in terminal

### Установка
```bash
npm install -g openbrawl
```

### Использование
```bash
openbrawl
```

### Или без установки
```bash
npx openbrawl
```
```

5. Прикрепите файл: `openbrawl-windows.exe`
6. Нажмите **Publish release**

## Шаг 7: Автоматическая публикация

После создания релиза, GitHub Actions:
1. Автоматически запустится
2. Опубликует пакет на npm
3. Отправит уведомление

## Альтернатива: GitHub Packages (без npmjs.com)

Если не хотите связываться с 2FA npmjs.org:

### 1. Измените `npm-package/package.json`:
```json
{
  "name": "@YOUR_USERNAME/openbrawl",
  "publishConfig": {
    "registry": "https://npm.pkg.github.com"
  }
}
```

### 2. workflow для GitHub Packages:
```yaml
name: Publish to GitHub Packages

on:
  release:
    types: [created]

jobs:
  publish:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      packages: write
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          registry-url: 'https://npm.pkg.github.com'
      
      - run: cd npm-package && npm ci
      
      - run: cd npm-package && npm publish
        env:
          NODE_AUTH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

### 3. Установка будет такой:
```bash
# Добавить в .npmrc
@YOUR_USERNAME:registry=https://npm.pkg.github.com

# Установить
npm install -g @YOUR_USERNAME/openbrawl
```

## ✅ Проверка

После публикации проверьте:
```bash
npm view openbrawl  # или @YOUR_USERNAME/openbrawl
npm install -g openbrawl
openbrawl
```

## 🎯 Итого для пользователей:

```bash
# Установка
npm install -g openbrawl

# Запуск
openbrawl

# Или без установки
npx openbrawl
```
