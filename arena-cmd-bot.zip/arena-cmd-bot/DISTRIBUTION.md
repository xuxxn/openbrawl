# Arena CMD - Installation & Distribution Guide

## Вариант 1: Pip Install (Для тех у кого есть Python)

```bash
pip install arena-cmd
arena
```

## Вариант 2: EXE Installer (Для всех, без Python)

### Скачать готовый файл:
1. Скачать `arena-setup.exe` из релизов
2. Установить
3. Запустить `arena` из меню Пуск или командной строки

### Или portable версия:
1. Скачать `arena-portable.zip`
2. Распаковать
3. Запустить `arena.exe`

## Вариант 3: NPM Style (Максимально просто)

```bash
npx arena-cmd
```

## Текущая реализация:

### Сборка EXE:
```bash
pip install pyinstaller
pyinstaller --onefile --name arena client.py
```

### Сборка Pip пакета:
```bash
cd client
python setup.py sdist bdist_wheel
twine upload dist/*
```

## Roadmap:

- [x] Базовый pip пакет
- [x] WebSocket сервер в боте
- [ ] Авто-обновление клиента
- [ ] Инсталлятор с GUI
- [ ] Мобильное приложение (Termux)
- [ ] Веб-версия (без установки)
