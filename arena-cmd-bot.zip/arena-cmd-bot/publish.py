#!/usr/bin/env python3
"""
Скрипт для публикации пакета на PyPI
"""
import subprocess
import sys
import os

def run_command(cmd, description):
    """Выполнение команды с выводом"""
    print(f"\n🔄 {description}...")
    print(f"   {cmd}")
    result = subprocess.run(cmd, shell=True)
    if result.returncode != 0:
        print(f"❌ Ошибка при: {description}")
        sys.exit(1)
    print(f"✅ {description} завершено")

def main():
    print("🚀 Публикация Arena CMD на PyPI\n")
    
    # Проверка установленных инструментов
    try:
        import setuptools
        import wheel
        import twine
    except ImportError:
        print("📦 Установка необходимых пакетов...")
        run_command("pip install setuptools wheel twine", "Установка инструментов")
    
    # Очистка
    run_command("python setup.py clean --all", "Очистка")
    
    # Удаление старых сборок
    if os.path.exists("dist"):
        import shutil
        shutil.rmtree("dist")
    if os.path.exists("build"):
        shutil.rmtree("build")
    
    # Сборка
    run_command("python setup.py sdist bdist_wheel", "Сборка пакета")
    
    # Проверка
    run_command("twine check dist/*", "Проверка пакета")
    
    # Загрузка на PyPI (тестовый)
    print("\n📤 Загрузка на PyPI...")
    print("   Для тестового сервера: twine upload --repository-url https://test.pypi.org/legacy/ dist/*")
    print("   Для продакшена: twine upload dist/*")
    
    choice = input("\nЗагрузить на production PyPI? (yes/no/test): ").lower().strip()
    
    if choice == "yes":
        run_command("twine upload dist/*", "Загрузка на PyPI")
        print("\n✅ Пакет опубликован!")
        print("   Установка: pip install arena-cmd")
    elif choice == "test":
        run_command("twine upload --repository-url https://test.pypi.org/legacy/ dist/*", "Загрузка на TestPyPI")
        print("\n✅ Пакет опубликован на TestPyPI!")
        print("   Установка: pip install -i https://test.pypi.org/simple/ arena-cmd")
    else:
        print("\n⏭️ Пропущено. Пакет собран в dist/")

if __name__ == "__main__":
    main()
